<!DOCTYPE html>
<html>
<head>
  <title>SPORTS-ECOMMERCE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <div style="display:inline-center;">
    <?php include 'header.php' ?>
  </div>
  <div style="display:inline-block;">

    <nav>
      <a style="margin-left:10px; font-size:120%;" href="adminhome.php">Home</a>
      <a style="margin-left:10px; font-size:120%;" href="viewcatagories.php">Categories</a>
      <a style="margin-left:10px; font-size:120%;" href="shop.php">All Shops</a> 
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">Campaign</a>
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">All Products</a> 
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">Brands</a> 
      <a style="margin-left:10px; font-size:120%;" href="login.php">Gift Cards</a>
      <a style="margin-left:10px; font-size:120%;" href="login.php">Customer Accounts</a>
      <a style="margin-left:10px; font-size:120%;" href="chat.php">Chat</a>
    </nav>
  </div>

  <div  style="max-width:1500px; background-color: white; margin-left:100px; margin-right:100px;">
  <h2 style="text-align: center; margin-top: 30px;">All Messages</h2>
<div style="background-color: DodgerBlue;">
  <h2 style="text-align: left; margin-top: 30px;  color: white; font-size: 120%; font-family: helvetica"><b> Nike Shop<b> </h2>
    <h2 style="text-align: left; margin-top: 7px;  color: black; font-size: 120%; font-family: helvetica"> Hello, I would love to discuss with you about my product list and pricing. </h2>

    <div style="padding: 5px">
      <button type="button" onClick="document.location.href='reply.php'">Reply</button> 
    </div>

  </div>

  <div style="background-color: DodgerBlue; margin-top: 15px;">
  <h2 style="text-align: left; margin-top: 30px;  color: white; font-size: 120%; font-family: helvetica"><b>Customer one<b> </h2>
    <h2 style="text-align: left; margin-top: 7px;  color: black; font-size: 120%; font-family: helvetica"> Hello, Can you please accept my gift card request? </h2>

    <div style="padding: 5px">
      <button type="button" onClick="document.location.href='reply.php'">Reply</button> 
    </div>

  </div>

  <div style="background-color: DodgerBlue; margin-top: 15px;">
  <h2 style="text-align: left; margin-top: 30px;  color: white; font-size: 120%; font-family: helvetica"><b>K sports<b> </h2>
    <h2 style="text-align: left; margin-top: 7px;  color: black; font-size: 120%; font-family: helvetica"> Hello, I want to add new category. </h2>

    <div style="padding: 5px">
      <button type="button" onClick="document.location.href='reply.php'">Reply</button> 
    </div>

  </div>



</div>

<div>
    <?php include 'footer.php' ?>
  </div>

</body>
</html>
