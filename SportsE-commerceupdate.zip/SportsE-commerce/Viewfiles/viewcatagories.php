<!DOCTYPE html>
<html>
<head>
  <title>SPORTS-ECOMMERCE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <div style="display:inline-center;">
    <?php include 'header.php' ?>
  </div>
  <div style="display:inline-block;">

    <nav>
      <a style="margin-left:10px; font-size:120%;" href="adminhome.php">Home</a>
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">Categories</a>
      <a style="margin-left:10px; font-size:120%;" href="shop.php">All Shops</a> 
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">Campaign</a>
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">All Products</a> 
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">Brands</a> 
      <a style="margin-left:10px; font-size:120%;" href="login.php">Gift Cards</a>
      <a style="margin-left:10px; font-size:120%;" href="login.php">Customer Accounts</a>
      <a style="margin-left:10px; font-size:120%;" href="chat.php">Chat</a>
    </nav>
  </div>
  <div>
  </div>

 


      <div>
    
    <pre><img src="o1.jpg" alt="Ludu"  style="width: 20%; margin-left: 10px;">
    
    <div style="margin-left: 60px;padding: 5px">
      <button style="margin-top:90px; font-size:80%; type="button" onClick="document.location.href='indoorSports.php'">Indoor sports Accessories</button> 
    </div>
         
      </div>
      
     
      <div>
    
    <pre><img src="o2.jpg" alt="Ludu"  style="width: 20%; margin-left: 10px;">
    
    <div style="margin-left: 60px;padding: 5px">
      <button style="margin-top:90px; font-size:80%; type="button" onClick="document.location.href='outdoorSports.php'">Outdoor sports Accessories</button> 
    </div>
         
      </div>
      
      <div>
    
    <pre><img src="o3.jpg" alt="Ludu"  style="width: 20%; margin-left: 10px;">
    
    <div style="margin-left: 60px;padding: 5px">
      <button style="margin-top:90px; font-size:80%; type="button" onClick="document.location.href='digitalSports.php'">Online sports Accessories</button> 
    </div>
         
      </div>
      
     <div>
    <?php include 'footer.php' ?>
  </div>
</body>
</html>