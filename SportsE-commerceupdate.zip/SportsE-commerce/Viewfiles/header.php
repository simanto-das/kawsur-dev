<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<style> h1 {text-align:center; } </style>
<?php  
   $title = "SPORTS-ECOMMERCE";
   echo "<h1>".$title."</h1>"
?>
</body>
</html>