<!DOCTYPE html>
<html>
<head>
  <title>SPORTS-ECOMMERCE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <div style="display:inline-center;">
    <?php include 'header.php' ?>
  </div>
  <div style="display:inline-block;">

    <nav>
      <a style="margin-left:10px; font-size:120%;" href="viewcatagories.php">Categories</a>
      <a style="margin-left:10px; font-size:120%;" href="Viewfiles/signupall.php">All Shops</a> 
      <a style="margin-left:10px; font-size:120%;" href="Viewfiles/signupall.php">Campaign</a>
      <a style="margin-left:10px; font-size:120%;" href="aboutus.php">About Us</a> 
      <a style="margin-left:10px; font-size:120%;" href="signupall.php">Sign Up Here</a> 
      <a style="margin-left:10px; font-size:120%;" href="loginadmin.php">Login</a>
    </nav>
  </div>

  
    
 
   <div>
    <h1>ABOUT US</h1>
   <br />
   
      <div>
         <P>SPORTS E-COMMERCE is the largest sports shopping destination in Bangladesh. Launched in 2020, the online store offers the widest range of sports products in categories ranging from latest sports accessories.

         SPORTS E-COMMERCE believes in “Delivering Happiness” with an excellent customer experience thus provides the most efficient delivery service through own logistics so that customers get a hassle-free product delivery at their doorstep. We help our local and international vendors as well as a lot of brands serving thousands of consumers from all over Bangladesh. We also offer free returns and various payment methods including Cash on delivery, Online Payments, Card on delivery and bKash with all of our products.
      </P>

         <div>
      <p>Follow us on Facebook and Twitter to stay updated about our latest offers and promotions. Happy online shpping!</p>
         </div> 
      </div>
      <br /><br />
      


      
         
      </div>

       <div>
    <?php include 'footer.php' ?>
  </div>
      
   </body>
   </html>