<!DOCTYPE html>
<html>
<head>
  <title>Sign Up All</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

  <div style="display:inline-center;">
    <?php include 'header.php' ?>
  </div>

  
  <div style="display:inline-block;">
    <h2>Sign Up</h2>
     <div style="display:inline-block;">
    
      <a href="signadmin.php"><h3>Admin Sign Up</h3></a> <br>
      <a href="signshop.php"><h3>Shop Sign Up</h3></a><br>
      <a href="signup.php"><h3>Customer Sign Up</h3></a><br>
    
  </div>
  </div>
<div>
    <?php include 'footer.php' ?>
  </div>
</body>
</html>