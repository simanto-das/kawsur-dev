<!DOCTYPE html>
<html>


<body>

 
		<form>
  			<input type="text" name="search" placeholder="Search">
  			<input type="submit" name="search" value="Search">
		</form>


     
   

    
</body>
</html>